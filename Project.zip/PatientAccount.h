#include <iostream>
#include "PatientAccount.h"
#include "Surgery.h"
//#include "Pharmacy.h"
using namespace std;

int main() {
  int theChoice;
  PatientAccount pt1();
  
    pt1.surgeryType(theChoice);
    cout<< pt1.getCharges;
  
}